"""Fleet management desktop application package."""

from .database import DatabaseManager
