from app.main_window import run


if __name__ == "__main__":
    run()
